import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Serve static files from attached_assets folder
app.use(express.static(path.join(__dirname, 'attached_assets')));

// Serve CSS files
app.use('/css', express.static(path.join(__dirname, 'attached_assets', 'css')));

// Serve JavaScript files
app.use('/js', express.static(path.join(__dirname, 'attached_assets', 'js')));

// Route for the index page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'attached_assets', 'index.html'));
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});