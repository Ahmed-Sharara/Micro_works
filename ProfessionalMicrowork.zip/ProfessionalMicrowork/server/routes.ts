import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";
import express from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // Serve static files from attached_assets folder
  app.use(express.static(path.join(process.cwd(), 'attached_assets')));

  // Serve CSS files from the css folder in attached_assets
  app.use('/css', express.static(path.join(process.cwd(), 'attached_assets', 'css')));
  
  // Serve JavaScript files from the js folder in attached_assets 
  app.use('/js', express.static(path.join(process.cwd(), 'attached_assets', 'js')));

  // Route for the index page
  app.get('/', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'attached_assets', 'index.html'));
  });

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  const httpServer = createServer(app);

  return httpServer;
}
